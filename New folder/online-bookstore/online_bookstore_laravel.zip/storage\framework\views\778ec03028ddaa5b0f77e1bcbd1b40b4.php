

<?php $__env->startSection('title', 'Catalog'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel-box p-3 mb-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center pb-2 mb-3 border-bottom gap-2">
        <div>
            <h5 class="fw-bold mb-0" style="color: var(--theme-main);">Available Books</h5>
            <span class="text-muted small">Check books below to compute the total cost.</span>
        </div>
        <div class="small fw-bold">
            Total Price: <span id="totalBox" class="cost-label">0.00 SAR</span>
        </div>
    </div>

    <form method="GET" action="<?php echo e(route('home')); ?>" class="row g-2 align-items-center">
        <div class="col-md-5">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Find by title or author..." value="<?php echo e(request('search')); ?>">
        </div>
        <div class="col-md-5">
            <select name="category" class="form-select form-select-sm">
                <option value="">All Categories</option>
                <?php $__currentLoopData = $cat_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c); ?>" <?php echo e(request('category') === $c ? 'selected' : ''); ?>><?php echo e($c); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-1">
            <button type="submit" class="btn btn-store btn-sm flex-grow-1">Search</button>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary btn-sm">Clear</a>
        </div>
    </form>
</div>

<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4">
            <div class="book-item h-100 d-flex flex-column overflow-hidden">
                <img src="<?php echo e($item->photo_url); ?>" alt="<?php echo e($item->title); ?>" class="w-100 border-bottom" style="height: 165px; object-fit: cover;">

                <div class="p-3 d-flex flex-column flex-grow-1">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="small text-muted"><?php echo e($item->category); ?></span>
                        <span class="cost-label"><?php echo e(number_format((float)$item->price, 2)); ?> SAR</span>
                    </div>

                    <h6 class="fw-bold mb-1"><?php echo e($item->title); ?></h6>
                    <div class="text-secondary small mb-3">
                        By <?php echo e($item->author); ?> &middot; Stock: <?php echo e($item->quantity); ?>

                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-2 mt-auto border-top small">
                        <div class="form-check mb-0">
                            <input type="checkbox" class="form-check-input pick-book" id="b_<?php echo e($item->id); ?>" data-cost="<?php echo e(number_format((float)$item->price, 2, '.', '')); ?>" onchange="updatePriceSum()">
                            <label class="form-check-label text-secondary" for="b_<?php echo e($item->id); ?>">Select</label>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="d-flex gap-1">
                                <a href="<?php echo e(route('books.edit', $item)); ?>" class="btn btn-sm btn-outline-secondary py-0 px-2">Edit</a>
                                <form action="<?php echo e(route('books.destroy', $item)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Remove this book?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2">Delete</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center text-muted py-5 panel-box">
            No matching books found.
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\New folder\online-bookstore\online-bookstore-laravel\resources\views/books/index.blade.php ENDPATH**/ ?>