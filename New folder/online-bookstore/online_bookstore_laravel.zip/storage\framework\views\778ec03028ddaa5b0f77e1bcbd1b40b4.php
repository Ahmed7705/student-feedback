<?php $__env->startSection('title', 'Catalog'); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-3 mb-3">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
        <div>
            <h5 class="fw-bold mb-0" style="color: var(--app-blue);">Book Catalog</h5>
            <span class="text-muted small">Browse books and select items to calculate total price.</span>
        </div>
        <div class="small fw-bold">
            Selected Total: <span id="selectedTotal" class="price-text">0.00 SAR</span>
        </div>
    </div>
</div>

<div class="card p-3 mb-4">
    <form method="GET" action="<?php echo e(route('home')); ?>" class="row g-2 align-items-center">
        <div class="col-md-5">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search title or author..." value="<?php echo e(request('search')); ?>">
        </div>
        <div class="col-md-5">
            <select name="category" class="form-select form-select-sm">
                <option value="">All Categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat); ?>" <?php echo e(request('category') === $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-1">
            <button type="submit" class="btn btn-blue btn-sm flex-grow-1">Filter</button>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary btn-sm">Reset</a>
        </div>
    </form>
</div>

<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <div class="card h-100 d-flex flex-column overflow-hidden">
                <img src="<?php echo e($b->image_url); ?>" alt="<?php echo e($b->title); ?>" class="card-img-top border-bottom" style="height: 150px; object-fit: cover;">

                <div class="p-3 d-flex flex-column flex-grow-1">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="small fw-semibold text-secondary"><?php echo e($b->category); ?></span>
                        <span class="price-text"><?php echo e(number_format((float)$b->price, 2)); ?> SAR</span>
                    </div>

                    <h6 class="fw-bold mb-1"><?php echo e($b->title); ?></h6>
                    <div class="text-muted small mb-2">
                        Author: <strong><?php echo e($b->author); ?></strong> &middot; Quantity: <strong><?php echo e($b->quantity); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-2 mt-auto border-top small">
                        <div class="form-check mb-0">
                            <input type="checkbox" class="form-check-input book-check" id="chk_<?php echo e($b->id); ?>" data-price="<?php echo e(number_format((float)$b->price, 2, '.', '')); ?>" onchange="calcTotal()">
                            <label class="form-check-label text-secondary" for="chk_<?php echo e($b->id); ?>">Select Book</label>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="d-flex gap-1">
                                <a href="<?php echo e(route('books.edit', $b)); ?>" class="btn btn-sm btn-outline-secondary py-0 px-2">Edit</a>
                                <form action="<?php echo e(route('books.destroy', $b)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this book?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2">Delete</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center text-muted py-5 bg-white rounded border">
            No books found.
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\New folder\online-bookstore\online-bookstore-laravel\resources\views/books/index.blade.php ENDPATH**/ ?>