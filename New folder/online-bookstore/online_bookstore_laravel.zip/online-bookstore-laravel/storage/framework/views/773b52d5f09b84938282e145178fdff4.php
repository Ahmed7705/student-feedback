<?php $__env->startSection('title', 'Edit Feedback'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="card p-4 bg-white">
            <h5 class="fw-bold mb-3" style="color: var(--app-blue);">Edit Course Feedback</h5>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger py-2 small">
                    <ul class="mb-0 ps-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('feedbacks.update', $feedback)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Course</label>
                    <select name="course_id" class="form-select form-select-sm" required>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>" <?php echo e(old('course_id', $feedback->course_id) == $c->id ? 'selected' : ''); ?>>
                                <?php echo e($c->course_code); ?> - <?php echo e($c->course_name); ?> (<?php echo e($c->instructor_name); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Student Name</label>
                    <input type="text" name="student_name" class="form-control form-control-sm" value="<?php echo e(old('student_name', $feedback->student_name)); ?>" required>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Category</label>
                        <select name="category" class="form-select form-select-sm" required>
                            <option value="Teaching Quality" <?php echo e($feedback->category == 'Teaching Quality' ? 'selected' : ''); ?>>Teaching Quality</option>
                            <option value="Course Content" <?php echo e($feedback->category == 'Course Content' ? 'selected' : ''); ?>>Course Content</option>
                            <option value="Lab & Practical" <?php echo e($feedback->category == 'Lab & Practical' ? 'selected' : ''); ?>>Lab & Practical</option>
                            <option value="Assessment & Grading" <?php echo e($feedback->category == 'Assessment & Grading' ? 'selected' : ''); ?>>Assessment & Grading</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Rating</label>
                        <select name="rating" class="form-select form-select-sm" required>
                            <option value="5" <?php echo e($feedback->rating == 5 ? 'selected' : ''); ?>>5 - Excellent (5/5)</option>
                            <option value="4" <?php echo e($feedback->rating == 4 ? 'selected' : ''); ?>>4 - Very Good (4/5)</option>
                            <option value="3" <?php echo e($feedback->rating == 3 ? 'selected' : ''); ?>>3 - Good (3/5)</option>
                            <option value="2" <?php echo e($feedback->rating == 2 ? 'selected' : ''); ?>>2 - Fair (2/5)</option>
                            <option value="1" <?php echo e($feedback->rating == 1 ? 'selected' : ''); ?>>1 - Poor (1/5)</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Feedback Title</label>
                    <input type="text" name="title" class="form-control form-control-sm" value="<?php echo e(old('title', $feedback->title)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Comments</label>
                    <textarea name="comments" rows="3" class="form-control form-control-sm" required><?php echo e(old('comments', $feedback->comments)); ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Update Image (Optional)</label>
                    <input type="file" name="image" class="form-control form-control-sm" accept="image/*">
                </div>

                <div class="form-check mb-4">
                    <input type="checkbox" name="is_anonymous" class="form-check-input" id="anon" value="1" <?php echo e($feedback->is_anonymous ? 'checked' : ''); ?>>
                    <label class="form-check-label small" for="anon">Submit Anonymously</label>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary btn-sm">Back</a>
                    <button type="submit" class="btn btn-blue btn-sm px-4">Update Feedback</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\student-feedback\resources\views/feedbacks/edit.blade.php ENDPATH**/ ?>