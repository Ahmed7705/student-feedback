<?php $__env->startSection('title', 'Course Reviews'); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-3 mb-4">
    <form method="GET" action="<?php echo e(route('home')); ?>" class="row g-2 align-items-center">
        <div class="col-md-5">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search feedback..." value="<?php echo e(request('search')); ?>">
        </div>
        <div class="col-md-5">
            <select name="course_id" class="form-select form-select-sm">
                <option value="">All Courses</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" <?php echo e(request('course_id') == $c->id ? 'selected' : ''); ?>>
                        <?php echo e($c->course_code); ?> - <?php echo e($c->course_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-1">
            <button type="submit" class="btn btn-blue btn-sm flex-grow-1">Filter</button>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary btn-sm">Reset</a>
        </div>
    </form>
</div>

<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <div class="card h-100 d-flex flex-column overflow-hidden">
                <img src="<?php echo e($fb->image_url); ?>" alt="<?php echo e($fb->course->course_name); ?>" class="card-img-top border-bottom" style="height: 150px; object-fit: cover;">

                <div class="p-3 d-flex flex-column flex-grow-1">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-bold" style="color: var(--app-blue); font-size: 0.9rem;"><?php echo e($fb->course->course_code); ?></span>
                        <span class="text-secondary small fw-semibold">Rating: <?php echo e($fb->rating); ?>/5</span>
                    </div>

                    <h6 class="fw-bold mb-1"><?php echo e($fb->title); ?></h6>
                    <div class="text-muted small mb-2">
                        Instructor: <strong><?php echo e($fb->course->instructor_name); ?></strong> &middot; <?php echo e($fb->category); ?>

                    </div>
                    <p class="text-secondary small mb-3 flex-grow-1"><?php echo e($fb->comments); ?></p>

                    <div class="d-flex justify-content-between align-items-center pt-2 border-top small text-muted">
                        <div>
                            Student: <strong><?php echo e($fb->is_anonymous ? 'Anonymous' : $fb->student_name); ?></strong>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="d-flex gap-1">
                                <a href="<?php echo e(route('feedbacks.edit', $fb)); ?>" class="btn btn-sm btn-outline-secondary py-0 px-2">Edit</a>
                                <form action="<?php echo e(route('feedbacks.destroy', $fb)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this feedback?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2">Delete</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center text-muted py-5 bg-white rounded border">
            No course reviews found.
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\student-feedback\resources\views/feedbacks/index.blade.php ENDPATH**/ ?>