<?php $__env->startSection('title', 'Manage Books'); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-4 bg-white">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0" style="color: var(--app-blue);">Manage Books</h5>
        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-blue btn-sm px-3">+ Add Book</a>
    </div>

    <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($b->title); ?></td>
                        <td class="text-secondary small"><?php echo e($b->author); ?></td>
                        <td class="text-secondary small"><?php echo e($b->category); ?></td>
                        <td class="price-text"><?php echo e(number_format((float)$b->price, 2)); ?> SAR</td>
                        <td class="small"><?php echo e($b->quantity); ?></td>
                        <td class="text-end">
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('books.edit', $b)); ?>" class="btn btn-sm btn-outline-secondary py-0 px-2">Edit</a>
                                <form action="<?php echo e(route('books.destroy', $b)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this book?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2">Delete</button>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="small text-decoration-none" style="color: var(--app-blue);">Login to edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No books found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\New folder\online-bookstore\online-bookstore-laravel\resources\views/books/manage.blade.php ENDPATH**/ ?>