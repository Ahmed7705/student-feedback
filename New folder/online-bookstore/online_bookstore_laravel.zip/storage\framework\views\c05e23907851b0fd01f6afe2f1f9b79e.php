

<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-3">
    <div class="col-md-5">
        <div class="panel-box p-4">
            <h5 class="fw-bold mb-3" style="color: var(--theme-main);">Sign In</h5>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger py-2 small text-center"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('login.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Email</label>
                    <input type="email" name="email" class="form-control form-control-sm" value="<?php echo e(old('email', 'admin@bookstore.com')); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Password</label>
                    <input type="password" name="password" class="form-control form-control-sm" placeholder="Password (e.g. 123456)" required>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-2">
                    <a href="<?php echo e(route('register')); ?>" class="small text-decoration-none" style="color: var(--theme-main);">New account</a>
                    <button type="submit" class="btn btn-store btn-sm px-4">Sign In</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\New folder\online-bookstore\online-bookstore-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>