

<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center my-4">
    <div class="col-md-5">
        <div class="panel-box p-4 p-md-5">
            <h4 class="fw-bold mb-1" style="color: var(--theme-main);">Sign In</h4>
            <div class="text-secondary small mb-4">Enter your credentials to access your account</div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger py-2 small text-center"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('login.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', 'admin@bookstore.com')); ?>" required>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-bold">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password (e.g. 123456)" required>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-2">
                    <a href="<?php echo e(route('register')); ?>" class="small text-decoration-none" style="color: var(--theme-main);">Create an account</a>
                    <button type="submit" class="btn btn-store px-4 py-2">Sign In</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ahmed\Documents\new\New folder\online-bookstore\online-bookstore-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>