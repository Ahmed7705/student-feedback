<?php
require_once __DIR__ . '/config.php';
$active_file = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= clean($view_title ?? 'Catalog') ?> | Online Bookstore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --theme-teal: #1f6f5c;
            --theme-dark: #165244;
            --theme-bg: #f3f7f5;
            --theme-ink: #1c2b27;
            --theme-line: #cfe0da;
        }
        body {
            background-color: var(--theme-bg);
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: var(--theme-ink);
        }
        .top-bar {
            background-color: var(--theme-teal);
            padding: 0.65rem 0;
        }
        .store-brand {
            font-size: 1.18rem;
            font-weight: 700;
            color: #ffffff;
            text-decoration: none;
            letter-spacing: 0.2px;
        }
        .store-brand:hover {
            color: #dff2ec;
        }
        .top-bar .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            font-size: 0.9rem;
            font-weight: 500;
            padding: 0.35rem 0.85rem !important;
            border-bottom: 2px solid transparent;
        }
        .top-bar .nav-link:hover {
            color: #ffffff !important;
        }
        .top-bar .nav-link.active {
            color: #ffffff !important;
            border-bottom: 2px solid #ffffff;
            font-weight: 600;
        }
        .btn-store {
            background-color: var(--theme-teal);
            color: #ffffff;
            border: 1px solid var(--theme-teal);
            font-weight: 500;
            border-radius: 4px;
        }
        .btn-store:hover {
            background-color: var(--theme-dark);
            border-color: var(--theme-dark);
            color: #ffffff;
        }
        .panel-box {
            border: 1px solid var(--theme-line);
            border-radius: 6px;
            background-color: #ffffff;
            box-shadow: none !important;
        }
        .book-item {
            border: 1px solid var(--theme-line);
            border-radius: 6px;
            background-color: #ffffff;
            border-top: 3px solid var(--theme-teal);
        }
        .form-control,
        .form-select {
            border-color: var(--theme-line);
            border-radius: 4px;
        }
        .form-control:focus,
        .form-select:focus,
        .form-check-input:focus,
        .btn:focus,
        .btn:active {
            box-shadow: none !important;
            outline: none !important;
            border-color: var(--theme-teal) !important;
        }
        .form-check-input:checked {
            background-color: var(--theme-teal);
            border-color: var(--theme-teal);
        }
        .cost-label {
            color: var(--theme-teal);
            font-weight: 700;
            font-size: 0.96rem;
        }
        .table th {
            color: var(--theme-teal);
            font-weight: 600;
            border-bottom-width: 1px;
        }
        .bottom-footer {
            background-color: var(--theme-teal);
            color: rgba(255, 255, 255, 0.92);
            padding: 0.7rem 0;
            font-size: 0.82rem;
            text-align: center;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark top-bar sticky-top">
        <div class="container">
            <a class="store-brand" href="index.php">Online Bookstore</a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#menuLinks">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="menuLinks">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-1 align-items-lg-center">
                    <li class="nav-item">
                        <a class="nav-link <?= $active_file === 'index.php' ? 'active' : '' ?>" href="index.php">Book Catalog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $active_file === 'create.php' ? 'active' : '' ?>" href="create.php">Add Book</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($active_file === 'manage.php' || $active_file === 'edit.php') ? 'active' : '' ?>" href="manage.php">Manage Books</a>
                    </li>
                    <?php if (!empty($_SESSION['account_name'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Sign Out (<?= clean($_SESSION['account_name']) ?>)</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $active_file === 'login.php' ? 'active' : '' ?>" href="login.php">Sign In</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= $active_file === 'register.php' ? 'active' : '' ?>" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container py-4 flex-grow-1">
        <?php if (!empty($_SESSION['msg_ok'])): ?>
            <div class="alert alert-success alert-dismissible fade show py-2 small" role="alert">
                <?= clean($_SESSION['msg_ok']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['msg_ok']); ?>
        <?php endif; ?>
